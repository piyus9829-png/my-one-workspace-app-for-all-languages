import React, { useState, useEffect, useCallback } from 'react';
import { 
  DEFAULT_FILES, 
  DEFAULT_NOTES, 
  INITIAL_SQL_SEED 
} from './data/defaultWorkspace';
import { 
  ExecutionResult, 
  LayoutMode, 
  SupportedLanguage, 
  WorkspaceFile, 
  WorkspaceNote 
} from './types';
import { executeCode, getSqliteDatabase, resetSqliteDatabase, inspectSqlTables } from './services/codeRunner';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { CodeEditor } from './components/CodeEditor';
import { OutputPanel } from './components/OutputPanel';
import { NotesPanel } from './components/NotesPanel';

const STORAGE_FILES_KEY = 'polycode_workspace_files_v1';
const STORAGE_NOTES_KEY = 'polycode_workspace_notes_v1';

export default function App() {
  // Load saved files and notes or fall back to defaults
  const [files, setFiles] = useState<WorkspaceFile[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_FILES_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed to load files from storage:', e);
    }
    return DEFAULT_FILES;
  });

  const [notes, setNotes] = useState<WorkspaceNote[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_NOTES_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed to load notes from storage:', e);
    }
    return DEFAULT_NOTES;
  });

  const [activeFileId, setActiveFileId] = useState<string>(() => files[0]?.id || 'file-sql-1');
  const [activeNoteId, setActiveNoteId] = useState<string>(() => notes[0]?.id || 'note-sql-1');
  const [layoutMode, setLayoutMode] = useState<LayoutMode>('split');
  const [stdin, setStdin] = useState<string>('');
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [isDbResetting, setIsDbResetting] = useState<boolean>(false);
  const [executionResult, setExecutionResult] = useState<ExecutionResult | null>(null);

  // Active file & note objects
  const activeFile = files.find((f) => f.id === activeFileId) || files[0];
  const activeNote = notes.find((n) => n.id === activeNoteId) || notes[0];

  // Auto-save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_FILES_KEY, JSON.stringify(files));
    } catch (e) {
      console.error('Failed to persist files:', e);
    }
  }, [files]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_NOTES_KEY, JSON.stringify(notes));
    } catch (e) {
      console.error('Failed to persist notes:', e);
    }
  }, [notes]);

  // Initial SQLite warm-up & schema inspection
  useEffect(() => {
    getSqliteDatabase()
      .then((db) => inspectSqlTables(db))
      .then((tables) => {
        setExecutionResult((prev) => ({
          status: 'idle',
          language: 'sql',
          stdout: 'Ready. SQLite WASM database initialized with sample tables (departments, employees, projects).',
          stderr: '',
          sqlTables: tables,
        }));
      })
      .catch((err) => {
        console.warn('SQLite background init notice:', err);
      });
  }, []);

  // Run active file code
  const handleRunCode = useCallback(async () => {
    if (!activeFile || isRunning) return;

    setIsRunning(true);
    try {
      const result = await executeCode(activeFile.language, activeFile.content, stdin);
      setExecutionResult(result);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setExecutionResult({
        status: 'error',
        language: activeFile.language,
        stdout: '',
        stderr: `Execution error: ${msg}`,
      });
    } finally {
      setIsRunning(false);
    }
  }, [activeFile, isRunning, stdin]);

  // Keyboard shortcut: Cmd/Ctrl + Enter
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
        e.preventDefault();
        handleRunCode();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleRunCode]);

  // Update active file content
  const handleFileContentChange = (newContent: string) => {
    setFiles((prev) =>
      prev.map((f) => (f.id === activeFileId ? { ...f, content: newContent, updatedAt: Date.now() } : f))
    );
  };

  // Create new file
  const handleCreateFile = (name: string, language: SupportedLanguage) => {
    const boilerplates: Record<SupportedLanguage, string> = {
      sql: `-- SQL Script: ${name}\nSELECT * FROM departments LIMIT 10;\n`,
      c: `/*\n * C Program: ${name}\n */\n#include <stdio.h>\n\nint main(void) {\n    printf("Hello from C!\\\\n");\n    return 0;\n}\n`,
      cpp: `/*\n * C++ Program: ${name}\n */\n#include <iostream>\n#include <vector>\n\nint main() {\n    std::cout << "Hello from C++!\\\\n";\n    return 0;\n}\n`,
      python: `"""\nPython Script: ${name}\n"""\n\ndef main():\n    print("Hello from Python!")\n\nif __name__ == "__main__":\n    main()\n`,
      markdown: `# Notes: ${name}\n\nAdd documentation here.\n`,
    };

    const newFile: WorkspaceFile = {
      id: `file-${Date.now()}`,
      name,
      language,
      content: boilerplates[language] || '',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    setFiles((prev) => [...prev, newFile]);
    setActiveFileId(newFile.id);
  };

  // Delete file
  const handleDeleteFile = (id: string) => {
    if (files.length <= 1) return;
    const remaining = files.filter((f) => f.id !== id);
    setFiles(remaining);
    if (activeFileId === id) {
      setActiveFileId(remaining[0].id);
    }
  };

  // Reset active file to initial template
  const handleResetActiveFile = () => {
    const defaultMatch = DEFAULT_FILES.find((f) => f.name === activeFile?.name || f.language === activeFile?.language);
    if (defaultMatch) {
      handleFileContentChange(defaultMatch.content);
    }
  };

  // Insert code snippet into current active file
  const handleInsertCodeSnippet = (snippet: string) => {
    if (!activeFile) return;
    const newContent = `${activeFile.content}\n\n${snippet}`;
    handleFileContentChange(newContent);
  };

  // Create new note
  const handleCreateNote = (topic: WorkspaceNote['languageTopic'] = 'general') => {
    const newNote: WorkspaceNote = {
      id: `note-${Date.now()}`,
      title: `Untitled Note ${notes.length + 1}`,
      languageTopic: topic,
      content: `# New Note\n\n- Key concepts:\n- Code snippet:\n\`\`\`${topic !== 'general' ? topic : 'python'}\n// Example code\n\`\`\`\n`,
      tags: [topic],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    setNotes((prev) => [newNote, ...prev]);
    setActiveNoteId(newNote.id);
  };

  // Update note
  const handleUpdateNote = (updated: WorkspaceNote) => {
    setNotes((prev) => prev.map((n) => (n.id === updated.id ? updated : n)));
  };

  // Delete note
  const handleDeleteNote = (id: string) => {
    if (notes.length <= 1) return;
    const remaining = notes.filter((n) => n.id !== id);
    setNotes(remaining);
    if (activeNoteId === id) {
      setActiveNoteId(remaining[0].id);
    }
  };

  // Send code snippet from editor into active note
  const handleSendToNotes = (snippet: string) => {
    if (!activeNote) {
      handleCreateNote((activeFile?.language as WorkspaceNote['languageTopic']) || 'general');
    }
    const targetNote = activeNote || notes[0];
    const updatedContent = `${targetNote.content}\n\n### Snippet (${activeFile?.name || 'Code'})\n${snippet}\n`;
    handleUpdateNote({
      ...targetNote,
      content: updatedContent,
      updatedAt: Date.now(),
    });

    // If in code-only mode, switch to split mode so user sees the clipped note!
    if (layoutMode === 'code-only') {
      setLayoutMode('split');
    }
  };

  // Reset database to default
  const handleResetDb = async () => {
    setIsDbResetting(true);
    try {
      await resetSqliteDatabase();
      const db = await getSqliteDatabase();
      const tables = await inspectSqlTables(db);
      setExecutionResult({
        status: 'success',
        language: 'sql',
        stdout: 'Database reset successfully. Tables populated with default datasets.',
        stderr: '',
        sqlTables: tables,
      });
    } catch (err: unknown) {
      console.error(err);
    } finally {
      setIsDbResetting(false);
    }
  };

  // Query a table directly from the schema browser
  const handleSelectTableQuery = (tableName: string) => {
    let sqlFile = files.find((f) => f.language === 'sql');
    if (!sqlFile) {
      handleCreateFile('queries.sql', 'sql');
      sqlFile = files.find((f) => f.language === 'sql');
    }

    const query = `\n-- Inspect table: ${tableName}\nSELECT * FROM "${tableName}" LIMIT 25;\n`;
    if (sqlFile) {
      setActiveFileId(sqlFile.id);
      const updated = `${sqlFile.content}\n${query}`;
      handleFileContentChange(updated);
    }
  };

  // Reset entire workspace
  const handleResetWorkspace = () => {
    if (window.confirm('Reset all workspace files and notes to default starters?')) {
      setFiles(DEFAULT_FILES);
      setNotes(DEFAULT_NOTES);
      setActiveFileId(DEFAULT_FILES[0].id);
      setActiveNoteId(DEFAULT_NOTES[0].id);
      handleResetDb();
    }
  };

  // Export workspace to JSON
  const handleExportWorkspace = () => {
    const data = {
      exportedAt: new Date().toISOString(),
      files,
      notes,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `workspace_backup_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Import workspace from JSON
  const handleImportWorkspace = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const parsed = JSON.parse(e.target?.result as string);
        if (parsed.files && Array.isArray(parsed.files)) {
          setFiles(parsed.files);
          setActiveFileId(parsed.files[0]?.id || 'file-sql-1');
        }
        if (parsed.notes && Array.isArray(parsed.notes)) {
          setNotes(parsed.notes);
          setActiveNoteId(parsed.notes[0]?.id || 'note-sql-1');
        }
      } catch {
        alert('Invalid workspace JSON file.');
      }
    };
    reader.readAsText(file);
  };

  // Download active file
  const handleDownloadActiveFile = () => {
    if (!activeFile) return;
    const blob = new Blob([activeFile.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeFile.name;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-neutral-950 text-neutral-100 overflow-hidden font-sans">
      {/* Top Navigation Header */}
      <Header
        layoutMode={layoutMode}
        onChangeLayoutMode={setLayoutMode}
        activeLanguage={activeFile?.language || 'sql'}
        activeFileName={activeFile?.name || 'queries.sql'}
        onRunCode={handleRunCode}
        isRunning={isRunning}
        notesCount={notes.length}
      />

      {/* Main Workspace Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar (Files, Cheat Sheets, Export/Import) */}
        <Sidebar
          files={files}
          activeFileId={activeFileId}
          onSelectFile={setActiveFileId}
          onCreateFile={handleCreateFile}
          onDeleteFile={handleDeleteFile}
          onInsertCodeSnippet={handleInsertCodeSnippet}
          onResetWorkspace={handleResetWorkspace}
          onExportWorkspace={handleExportWorkspace}
          onImportWorkspace={handleImportWorkspace}
          onDownloadActiveFile={handleDownloadActiveFile}
          notesCount={notes.length}
        />

        {/* Center / Right Content Area based on Layout Mode */}
        <main className="flex-1 flex overflow-hidden p-2 gap-2 bg-neutral-950">
          {/* Layout Mode: Split Workspace (Code Editor + Terminal on Left, Notes on Right) */}
          {layoutMode === 'split' && (
            <>
              {/* Left Column: Editor & Terminal */}
              <div className="w-1/2 flex flex-col gap-2 h-full overflow-hidden">
                <div className="h-[55%]">
                  <CodeEditor
                    file={activeFile}
                    onChange={handleFileContentChange}
                    onRun={handleRunCode}
                    isRunning={isRunning}
                    onSendToNotes={handleSendToNotes}
                    onResetFile={handleResetActiveFile}
                  />
                </div>
                <div className="h-[45%]">
                  <OutputPanel
                    result={executionResult}
                    language={activeFile?.language || 'sql'}
                    stdin={stdin}
                    onStdinChange={setStdin}
                    onClearOutput={() => setExecutionResult(null)}
                    onResetDb={handleResetDb}
                    onSelectTableQuery={handleSelectTableQuery}
                    isDbResetting={isDbResetting}
                  />
                </div>
              </div>

              {/* Right Column: Notes Companion */}
              <div className="w-1/2 h-full overflow-hidden">
                <NotesPanel
                  notes={notes}
                  activeNoteId={activeNoteId}
                  onSelectNote={setActiveNoteId}
                  onUpdateNote={handleUpdateNote}
                  onCreateNote={handleCreateNote}
                  onDeleteNote={handleDeleteNote}
                  onInsertIntoCode={handleInsertCodeSnippet}
                  activeCodeFileName={activeFile?.name}
                  isCompact={false}
                />
              </div>
            </>
          )}

          {/* Layout Mode: Code Studio (Full Width Editor & Terminal) */}
          {layoutMode === 'code-only' && (
            <div className="w-full flex flex-col gap-2 h-full overflow-hidden">
              <div className="h-[58%]">
                <CodeEditor
                  file={activeFile}
                  onChange={handleFileContentChange}
                  onRun={handleRunCode}
                  isRunning={isRunning}
                  onSendToNotes={handleSendToNotes}
                  onResetFile={handleResetActiveFile}
                />
              </div>
              <div className="h-[42%]">
                <OutputPanel
                  result={executionResult}
                  language={activeFile?.language || 'sql'}
                  stdin={stdin}
                  onStdinChange={setStdin}
                  onClearOutput={() => setExecutionResult(null)}
                  onResetDb={handleResetDb}
                  onSelectTableQuery={handleSelectTableQuery}
                  isDbResetting={isDbResetting}
                />
              </div>
            </div>
          )}

          {/* Layout Mode: Notes Only */}
          {layoutMode === 'notes-only' && (
            <div className="w-full h-full overflow-hidden">
              <NotesPanel
                notes={notes}
                activeNoteId={activeNoteId}
                onSelectNote={setActiveNoteId}
                onUpdateNote={handleUpdateNote}
                onCreateNote={handleCreateNote}
                onDeleteNote={handleDeleteNote}
                onInsertIntoCode={handleInsertCodeSnippet}
                activeCodeFileName={activeFile?.name}
                isCompact={false}
              />
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
