import React, { useState } from 'react';
import Markdown from 'react-markdown';
import { 
  BookOpen, 
  Plus, 
  Trash2, 
  Copy, 
  Check, 
  Eye, 
  Edit3, 
  Tag, 
  Search, 
  Code2, 
  Download, 
  Sparkles,
  Link,
  ChevronRight
} from 'lucide-react';
import { WorkspaceNote } from '../types';

interface NotesPanelProps {
  notes: WorkspaceNote[];
  activeNoteId: string;
  onSelectNote: (id: string) => void;
  onUpdateNote: (updated: WorkspaceNote) => void;
  onCreateNote: (languageTopic?: WorkspaceNote['languageTopic']) => void;
  onDeleteNote: (id: string) => void;
  onInsertIntoCode?: (snippet: string) => void;
  activeCodeFileName?: string;
  isCompact?: boolean;
}

export const NotesPanel: React.FC<NotesPanelProps> = ({
  notes,
  activeNoteId,
  onSelectNote,
  onUpdateNote,
  onCreateNote,
  onDeleteNote,
  onInsertIntoCode,
  activeCodeFileName,
  isCompact = false,
}) => {
  const [isPreview, setIsPreview] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTopic, setFilterTopic] = useState<string>('all');
  const [copied, setCopied] = useState(false);
  const [newTagInput, setNewTagInput] = useState('');

  const activeNote = notes.find((n) => n.id === activeNoteId) || notes[0];

  const filteredNotes = notes.filter((n) => {
    const matchesSearch =
      n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.tags.some((t) => t.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesTopic = filterTopic === 'all' || n.languageTopic === filterTopic;
    return matchesSearch && matchesTopic;
  });

  const handleCopyNote = () => {
    if (!activeNote) return;
    navigator.clipboard.writeText(activeNote.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportNote = () => {
    if (!activeNote) return;
    const blob = new Blob([activeNote.content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activeNote.title.toLowerCase().replace(/\s+/g, '_')}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleAddTag = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && newTagInput.trim() && activeNote) {
      e.preventDefault();
      const cleaned = newTagInput.trim().toLowerCase();
      if (!activeNote.tags.includes(cleaned)) {
        onUpdateNote({
          ...activeNote,
          tags: [...activeNote.tags, cleaned],
          updatedAt: Date.now(),
        });
      }
      setNewTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    if (!activeNote) return;
    onUpdateNote({
      ...activeNote,
      tags: activeNote.tags.filter((t) => t !== tagToRemove),
      updatedAt: Date.now(),
    });
  };

  const getTopicColor = (topic: WorkspaceNote['languageTopic']) => {
    switch (topic) {
      case 'sql': return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
      case 'c': return 'text-blue-400 bg-blue-500/10 border-blue-500/30';
      case 'cpp': return 'text-indigo-400 bg-indigo-500/10 border-indigo-500/30';
      case 'python': return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
      default: return 'text-purple-400 bg-purple-500/10 border-purple-500/30';
    }
  };

  return (
    <div className="flex h-full bg-neutral-900/90 border border-neutral-800 rounded-xl overflow-hidden shadow-2xl">
      {/* Left Column: Notes List */}
      <div className={`${isCompact ? 'w-56' : 'w-64'} flex flex-col border-r border-neutral-800 bg-neutral-950/70 select-none`}>
        {/* Top bar */}
        <div className="p-3 border-b border-neutral-800">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 font-semibold text-neutral-200 text-xs">
              <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
              <span>Workspace Notes</span>
            </div>
            <button
              onClick={() => onCreateNote(filterTopic !== 'all' ? (filterTopic as WorkspaceNote['languageTopic']) : 'general')}
              className="p-1 text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition"
              title="Create new note"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Search */}
          <div className="relative mb-2">
            <Search className="w-3 h-3 absolute left-2 top-2 text-neutral-500" />
            <input
              type="text"
              placeholder="Search notes & tags..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-neutral-900 border border-neutral-800 rounded-md pl-7 pr-2 py-1 text-[11px] text-neutral-200 focus:outline-none focus:border-neutral-700 placeholder:text-neutral-600"
            />
          </div>

          {/* Topic Pills */}
          <div className="flex flex-wrap gap-1">
            {['all', 'sql', 'c', 'cpp', 'python', 'general'].map((topic) => (
              <button
                key={topic}
                onClick={() => setFilterTopic(topic)}
                className={`px-1.5 py-0.5 text-[10px] uppercase font-medium rounded transition ${
                  filterTopic === topic
                    ? 'bg-neutral-700 text-white font-bold'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60'
                }`}
              >
                {topic}
              </button>
            ))}
          </div>
        </div>

        {/* Notes Items */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {filteredNotes.map((note) => {
            const isSelected = activeNote?.id === note.id;
            return (
              <button
                key={note.id}
                onClick={() => onSelectNote(note.id)}
                className={`w-full text-left p-2.5 rounded-lg transition group border ${
                  isSelected
                    ? 'bg-neutral-800/90 border-neutral-700 shadow-sm text-neutral-100'
                    : 'bg-neutral-900/30 border-transparent hover:bg-neutral-800/40 text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium text-xs truncate mr-1">{note.title}</span>
                  <span
                    className={`text-[9px] uppercase px-1.5 py-0.2 rounded-full border ${getTopicColor(
                      note.languageTopic
                    )}`}
                  >
                    {note.languageTopic}
                  </span>
                </div>
                <p className="text-[11px] text-neutral-500 line-clamp-1">
                  {note.content.replace(/[#*`_]/g, '')}
                </p>
                {note.tags.length > 0 && (
                  <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                    {note.tags.slice(0, 2).map((t) => (
                      <span key={t} className="text-[9px] text-neutral-400 bg-neutral-900/80 px-1 rounded">
                        #{t}
                      </span>
                    ))}
                    {note.tags.length > 2 && (
                      <span className="text-[9px] text-neutral-500">+{note.tags.length - 2}</span>
                    )}
                  </div>
                )}
              </button>
            );
          })}

          {filteredNotes.length === 0 && (
            <div className="text-center text-neutral-600 text-xs py-8">
              No notes match your filter.
            </div>
          )}
        </div>
      </div>

      {/* Right Column: Active Note Editor & Preview */}
      <div className="flex-1 flex flex-col overflow-hidden bg-neutral-950">
        {activeNote ? (
          <>
            {/* Note Header Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-neutral-900 border-b border-neutral-800">
              <div className="flex-1 min-w-[200px]">
                <input
                  type="text"
                  value={activeNote.title}
                  onChange={(e) =>
                    onUpdateNote({
                      ...activeNote,
                      title: e.target.value,
                      updatedAt: Date.now(),
                    })
                  }
                  className="w-full bg-transparent font-semibold text-sm text-neutral-100 focus:outline-none focus:border-b focus:border-indigo-500 pb-0.5"
                  placeholder="Note Title..."
                />
              </div>

              <div className="flex items-center gap-1.5">
                {/* Topic Selector */}
                <select
                  value={activeNote.languageTopic}
                  onChange={(e) =>
                    onUpdateNote({
                      ...activeNote,
                      languageTopic: e.target.value as WorkspaceNote['languageTopic'],
                      updatedAt: Date.now(),
                    })
                  }
                  className="bg-neutral-800 text-xs text-neutral-300 border border-neutral-700 rounded-lg px-2 py-1 outline-none"
                >
                  <option value="general">General</option>
                  <option value="sql">SQL</option>
                  <option value="c">C</option>
                  <option value="cpp">C++</option>
                  <option value="python">Python</option>
                </select>

                {/* Edit vs Preview Toggle */}
                <div className="flex items-center bg-neutral-800 rounded-lg p-0.5 border border-neutral-700 text-xs">
                  <button
                    onClick={() => setIsPreview(false)}
                    className={`flex items-center gap-1 px-2 py-1 rounded transition ${
                      !isPreview
                        ? 'bg-neutral-700 text-white font-semibold'
                        : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                    title="Edit Markdown"
                  >
                    <Edit3 className="w-3 h-3" />
                    <span className="hidden sm:inline">Edit</span>
                  </button>
                  <button
                    onClick={() => setIsPreview(true)}
                    className={`flex items-center gap-1 px-2 py-1 rounded transition ${
                      isPreview
                        ? 'bg-neutral-700 text-white font-semibold'
                        : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                    title="Preview Markdown"
                  >
                    <Eye className="w-3 h-3" />
                    <span className="hidden sm:inline">Preview</span>
                  </button>
                </div>

                {/* Insert into active code file */}
                {onInsertIntoCode && (
                  <button
                    onClick={() => onInsertIntoCode(activeNote.content)}
                    className="flex items-center gap-1 px-2.5 py-1 text-xs text-indigo-300 hover:text-indigo-100 bg-indigo-950/50 hover:bg-indigo-900/60 border border-indigo-800/40 rounded-lg transition"
                    title={`Insert into ${activeCodeFileName || 'editor'}`}
                  >
                    <Code2 className="w-3.5 h-3.5" />
                    <span className="hidden md:inline">Paste to Code</span>
                  </button>
                )}

                {/* Copy note */}
                <button
                  onClick={handleCopyNote}
                  className="p-1.5 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 rounded transition"
                  title="Copy Note Content"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>

                {/* Export note */}
                <button
                  onClick={handleExportNote}
                  className="p-1.5 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 rounded transition"
                  title="Download .md file"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>

                {/* Delete note */}
                <button
                  onClick={() => onDeleteNote(activeNote.id)}
                  disabled={notes.length <= 1}
                  className="p-1.5 text-neutral-400 hover:text-rose-400 hover:bg-neutral-800 disabled:opacity-30 rounded transition"
                  title="Delete Note"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Tags Strip */}
            <div className="flex items-center gap-1 px-3 py-1.5 bg-neutral-900/40 border-b border-neutral-800/60 text-xs flex-wrap">
              <Tag className="w-3 h-3 text-neutral-500 mr-1" />
              {activeNote.tags.map((tag) => (
                <span
                  key={tag}
                  className="group flex items-center gap-1 bg-neutral-800/70 border border-neutral-700/60 text-neutral-300 text-[10px] px-1.5 py-0.5 rounded"
                >
                  <span>#{tag}</span>
                  <button
                    onClick={() => handleRemoveTag(tag)}
                    className="text-neutral-500 hover:text-rose-400 transition"
                  >
                    ×
                  </button>
                </span>
              ))}
              <input
                type="text"
                value={newTagInput}
                onChange={(e) => setNewTagInput(e.target.value)}
                onKeyDown={handleAddTag}
                placeholder="+ tag (Enter)"
                className="bg-transparent text-[10px] text-neutral-400 placeholder:text-neutral-600 focus:outline-none w-20 px-1"
              />
            </div>

            {/* Note Body: Markdown Editor or Rendered Preview */}
            <div className="flex-1 overflow-y-auto p-4">
              {isPreview ? (
                <div className="markdown-body max-w-none">
                  <Markdown>{activeNote.content}</Markdown>
                </div>
              ) : (
                <textarea
                  value={activeNote.content}
                  onChange={(e) =>
                    onUpdateNote({
                      ...activeNote,
                      content: e.target.value,
                      updatedAt: Date.now(),
                    })
                  }
                  placeholder="Write your markdown notes, code snippets, explanations, or algorithms here..."
                  className="w-full h-full p-2 bg-transparent text-neutral-200 font-mono text-xs leading-relaxed focus:outline-none resize-none"
                  spellCheck="false"
                />
              )}
            </div>
          </>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-neutral-500 p-6">
            <BookOpen className="w-8 h-8 mb-2 text-neutral-600" />
            <p className="text-xs">No note selected. Create a new note to begin.</p>
          </div>
        )}
      </div>
    </div>
  );
};
