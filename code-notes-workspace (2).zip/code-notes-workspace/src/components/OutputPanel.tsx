import React, { useState } from 'react';
import { 
  Terminal, 
  Table2, 
  Database, 
  Keyboard, 
  Trash2, 
  Copy, 
  Check, 
  Download, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Layers, 
  RefreshCw,
  Search,
  ExternalLink
} from 'lucide-react';
import { ExecutionResult, SupportedLanguage, SqlTableInfo } from '../types';

interface OutputPanelProps {
  result: ExecutionResult | null;
  language: SupportedLanguage;
  stdin: string;
  onStdinChange: (val: string) => void;
  onClearOutput: () => void;
  onResetDb?: () => void;
  onSelectTableQuery?: (tableName: string) => void;
  isDbResetting?: boolean;
}

export const OutputPanel: React.FC<OutputPanelProps> = ({
  result,
  language,
  stdin,
  onStdinChange,
  onClearOutput,
  onResetDb,
  onSelectTableQuery,
  isDbResetting,
}) => {
  const [activeTab, setActiveTab] = useState<'console' | 'table' | 'schema' | 'stdin'>('console');
  const [copied, setCopied] = useState(false);
  const [tableFilter, setTableFilter] = useState('');

  // Switch automatically to table tab if SQL executed with results
  React.useEffect(() => {
    if (result && result.language === 'sql' && result.sqlResult && result.status === 'success') {
      setActiveTab('table');
    } else if (result) {
      setActiveTab('console');
    }
  }, [result]);

  const handleCopyOutput = () => {
    const text = result ? `${result.stdout}\n${result.stderr}` : '';
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportCsv = () => {
    if (!result?.sqlResult) return;
    const { columns, values } = result.sqlResult;
    const csvContent = [
      columns.join(','),
      ...values.map((row) =>
        row
          .map((cell) => {
            if (cell === null || cell === undefined) return '';
            const str = String(cell);
            return str.includes(',') ? `"${str.replace(/"/g, '""')}"` : str;
          })
          .join(',')
      ),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `query_result_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Filter SQL results
  const filteredSqlValues = React.useMemo(() => {
    if (!result?.sqlResult) return [];
    if (!tableFilter) return result.sqlResult.values;
    return result.sqlResult.values.filter((row) =>
      row.some((cell) => String(cell).toLowerCase().includes(tableFilter.toLowerCase()))
    );
  }, [result?.sqlResult, tableFilter]);

  return (
    <div className="flex flex-col h-full bg-neutral-900/90 border border-neutral-800 rounded-xl overflow-hidden shadow-2xl">
      {/* Header Tabs */}
      <div className="flex items-center justify-between px-3 py-2 bg-neutral-900 border-b border-neutral-800 select-none">
        <div className="flex items-center gap-1">
          {/* Console Tab */}
          <button
            onClick={() => setActiveTab('console')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
              activeTab === 'console'
                ? 'bg-neutral-800 text-neutral-100 border border-neutral-700/60 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-indigo-400" />
            <span>Output Console</span>
            {result?.status === 'error' && (
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
            )}
          </button>

          {/* SQL Table Tab (visible for SQL or when result has SQL data) */}
          {(language === 'sql' || result?.sqlResult) && (
            <button
              onClick={() => setActiveTab('table')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                activeTab === 'table'
                  ? 'bg-neutral-800 text-neutral-100 border border-neutral-700/60 shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
              }`}
            >
              <Table2 className="w-3.5 h-3.5 text-amber-400" />
              <span>Query Results</span>
              {result?.sqlResult && (
                <span className="px-1.5 py-0.2 text-[10px] bg-amber-500/20 text-amber-300 rounded font-mono">
                  {result.sqlResult.values.length}
                </span>
              )}
            </button>
          )}

          {/* Database Schema Inspector (for SQL) */}
          {language === 'sql' && (
            <button
              onClick={() => setActiveTab('schema')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                activeTab === 'schema'
                  ? 'bg-neutral-800 text-neutral-100 border border-neutral-700/60 shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
              }`}
            >
              <Database className="w-3.5 h-3.5 text-emerald-400" />
              <span>Database Schema</span>
            </button>
          )}

          {/* Standard Input (stdin) Tab (for C/C++/Python interactive input) */}
          {language !== 'sql' && (
            <button
              onClick={() => setActiveTab('stdin')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                activeTab === 'stdin'
                  ? 'bg-neutral-800 text-neutral-100 border border-neutral-700/60 shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
              }`}
            >
              <Keyboard className="w-3.5 h-3.5 text-cyan-400" />
              <span>Program Input (stdin)</span>
              {stdin.trim().length > 0 && (
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
              )}
            </button>
          )}
        </div>

        {/* Action controls & metrics */}
        <div className="flex items-center gap-2">
          {result && (
            <div className="hidden sm:flex items-center gap-2 font-mono text-[11px] text-neutral-400 mr-1">
              {result.status === 'success' ? (
                <span className="flex items-center gap-1 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Success</span>
                </span>
              ) : result.status === 'error' ? (
                <span className="flex items-center gap-1 text-rose-400">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>Exit {result.exitCode ?? 'Err'}</span>
                </span>
              ) : null}

              {result.executionTimeMs !== undefined && (
                <span className="flex items-center gap-1 text-neutral-400 border-l border-neutral-700 pl-2">
                  <Clock className="w-3 h-3" />
                  <span>{result.executionTimeMs}ms</span>
                </span>
              )}
            </div>
          )}

          {activeTab === 'table' && result?.sqlResult && (
            <button
              onClick={handleExportCsv}
              className="flex items-center gap-1 px-2 py-1 text-xs text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded transition"
              title="Download CSV"
            >
              <Download className="w-3 h-3 text-amber-400" />
              <span className="hidden md:inline">CSV</span>
            </button>
          )}

          <button
            onClick={handleCopyOutput}
            disabled={!result}
            className="p-1.5 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 disabled:opacity-30 rounded transition"
            title="Copy Output"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={onClearOutput}
            className="p-1.5 text-neutral-400 hover:text-rose-400 hover:bg-neutral-800 rounded transition"
            title="Clear Console"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Tab Panels */}
      <div className="flex-1 overflow-hidden bg-neutral-950 p-3 font-mono text-xs">
        {/* TAB 1: Console Output */}
        {activeTab === 'console' && (
          <div className="h-full overflow-y-auto space-y-2 select-text">
            {!result ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-neutral-500 font-sans p-6">
                <div className="w-12 h-12 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-neutral-400 mb-3 shadow-inner">
                  <Terminal className="w-6 h-6 text-neutral-400" />
                </div>
                <h4 className="text-sm font-medium text-neutral-300 mb-1">Terminal Output Ready</h4>
                <p className="text-xs text-neutral-500 max-w-xs leading-relaxed">
                  Run your code with the green button or press <kbd className="px-1 py-0.5 bg-neutral-800 rounded text-neutral-300 border border-neutral-700">Cmd / Ctrl + Enter</kbd> to execute.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {/* Compiler or Runtime Errors */}
                {result.stderr && (
                  <div className="p-3 bg-rose-950/40 border border-rose-800/40 rounded-lg text-rose-300 whitespace-pre-wrap leading-5">
                    <div className="flex items-center gap-1.5 text-rose-400 font-semibold mb-1 text-[11px] uppercase tracking-wider">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>Errors & Warnings</span>
                    </div>
                    {result.stderr}
                  </div>
                )}

                {/* Standard Output */}
                {result.stdout && (
                  <div className="p-3 bg-neutral-900/60 border border-neutral-800/60 rounded-lg text-emerald-300 whitespace-pre-wrap leading-5">
                    {result.stdout}
                  </div>
                )}

                {!result.stdout && !result.stderr && (
                  <div className="text-neutral-500 italic">
                    Program exited with code {result.exitCode ?? 0} (No output produced).
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: Interactive SQL Query Results Table */}
        {activeTab === 'table' && (
          <div className="h-full flex flex-col overflow-hidden">
            {result?.sqlResult ? (
              <>
                {/* Table search & row counter */}
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-neutral-800">
                  <div className="relative w-64">
                    <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-neutral-500" />
                    <input
                      type="text"
                      placeholder="Filter rows..."
                      value={tableFilter}
                      onChange={(e) => setTableFilter(e.target.value)}
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-md pl-8 pr-2.5 py-1 text-xs text-neutral-200 focus:outline-none focus:border-neutral-700"
                    />
                  </div>
                  <span className="text-[11px] text-neutral-400">
                    Showing {filteredSqlValues.length} of {result.sqlResult.values.length} rows
                  </span>
                </div>

                {/* Table Data Grid */}
                <div className="flex-1 overflow-auto rounded-lg border border-neutral-800">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-neutral-900 sticky top-0 border-b border-neutral-800 z-10">
                        <th className="py-2 px-3 text-[10px] text-neutral-500 font-medium uppercase tracking-wider w-10 text-center">
                          #
                        </th>
                        {result.sqlResult.columns.map((col, idx) => (
                          <th
                            key={idx}
                            className="py-2 px-3 text-[11px] font-semibold text-neutral-200 border-r border-neutral-800/60 last:border-none uppercase tracking-wider"
                          >
                            {col}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-900">
                      {filteredSqlValues.map((row, rowIdx) => (
                        <tr
                          key={rowIdx}
                          className="hover:bg-neutral-900/60 transition-colors odd:bg-neutral-950 even:bg-neutral-900/20"
                        >
                          <td className="py-2 px-3 text-[10px] text-neutral-600 text-center select-none font-mono">
                            {rowIdx + 1}
                          </td>
                          {row.map((cell, colIdx) => (
                            <td
                              key={colIdx}
                              className="py-2 px-3 text-neutral-300 border-r border-neutral-900/80 last:border-none whitespace-nowrap"
                            >
                              {cell === null ? (
                                <span className="text-neutral-600 italic">NULL</span>
                              ) : typeof cell === 'number' ? (
                                <span className="text-amber-400">{cell}</span>
                              ) : (
                                String(cell)
                              )}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center text-neutral-500 font-sans p-6">
                <Table2 className="w-8 h-8 text-neutral-600 mb-2" />
                <p className="text-xs">No active SQL query results yet. Run a SELECT query in the editor.</p>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: Database Schema Inspector */}
        {activeTab === 'schema' && (
          <div className="h-full flex flex-col overflow-y-auto space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-emerald-400" />
                <span className="font-semibold text-neutral-200 font-sans text-xs">
                  Active SQLite Database Tables
                </span>
              </div>
              {onResetDb && (
                <button
                  onClick={onResetDb}
                  disabled={isDbResetting}
                  className="flex items-center gap-1.5 px-2.5 py-1 text-xs text-rose-300 hover:text-rose-100 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/50 rounded-lg transition"
                >
                  <RefreshCw className={`w-3 h-3 ${isDbResetting ? 'animate-spin' : ''}`} />
                  <span>Reset DB to Default</span>
                </button>
              )}
            </div>

            {/* Tables list */}
            {result?.sqlTables && result.sqlTables.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {result.sqlTables.map((table) => (
                  <div
                    key={table.name}
                    className="p-3 bg-neutral-900/70 border border-neutral-800 rounded-lg flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-1.5 font-bold text-neutral-100">
                          <Database className="w-3.5 h-3.5 text-emerald-400" />
                          <span>{table.name}</span>
                        </div>
                        <span className="text-[11px] px-1.5 py-0.5 bg-neutral-800 text-neutral-400 rounded-md font-mono">
                          {table.rowCount} rows
                        </span>
                      </div>
                      {/* Columns */}
                      <div className="space-y-1 mb-3">
                        {table.columns.map((col) => (
                          <div
                            key={col.name}
                            className="flex items-center justify-between text-[11px] py-0.5 px-1.5 bg-neutral-950/60 rounded text-neutral-300"
                          >
                            <span className="text-neutral-200 font-medium">{col.name}</span>
                            <span className="text-emerald-400/80 font-mono text-[10px]">{col.type}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {onSelectTableQuery && (
                      <button
                        onClick={() => onSelectTableQuery(table.name)}
                        className="w-full flex items-center justify-center gap-1 py-1 text-xs text-emerald-400 hover:text-emerald-300 bg-emerald-950/30 hover:bg-emerald-950/60 border border-emerald-800/40 rounded transition mt-1"
                      >
                        <span>Query Table</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-neutral-500 p-4 text-center">
                Run an SQL query to load or refresh database tables.
              </div>
            )}
          </div>
        )}

        {/* TAB 4: Standard Input (stdin) */}
        {activeTab === 'stdin' && (
          <div className="h-full flex flex-col font-sans">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-neutral-300 font-medium">Standard Input Buffer</span>
              <span className="text-[11px] text-neutral-500 font-mono">
                Passed to scanf(), std::cin, input()
              </span>
            </div>
            <textarea
              value={stdin}
              onChange={(e) => onStdinChange(e.target.value)}
              placeholder="Enter input lines to feed into your program before running...&#10;Example:&#10;42&#10;Alice&#10;3.14"
              className="flex-1 w-full p-3 bg-neutral-900 border border-neutral-800 rounded-lg text-neutral-200 font-mono text-xs focus:outline-none focus:border-neutral-700 resize-none"
            />
          </div>
        )}
      </div>
    </div>
  );
};
