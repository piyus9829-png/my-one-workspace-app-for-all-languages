import React from 'react';
import { 
  Play, 
  Columns, 
  Code, 
  BookOpen, 
  Terminal, 
  Sparkles, 
  Cpu,
  Layers
} from 'lucide-react';
import { LayoutMode, SupportedLanguage } from '../types';

interface HeaderProps {
  layoutMode: LayoutMode;
  onChangeLayoutMode: (mode: LayoutMode) => void;
  activeLanguage: SupportedLanguage;
  activeFileName: string;
  onRunCode: () => void;
  isRunning: boolean;
  notesCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  layoutMode,
  onChangeLayoutMode,
  activeLanguage,
  activeFileName,
  onRunCode,
  isRunning,
  notesCount,
}) => {
  const getLanguageTag = (lang: SupportedLanguage) => {
    switch (lang) {
      case 'sql': return { label: 'SQL (SQLite WASM)', bg: 'bg-amber-500/20 text-amber-300 border-amber-500/40' };
      case 'c': return { label: 'C (GCC 10.2)', bg: 'bg-blue-500/20 text-blue-300 border-blue-500/40' };
      case 'cpp': return { label: 'C++ (G++ 10.2)', bg: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40' };
      case 'python': return { label: 'Python 3.10', bg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' };
      default: return { label: 'Markdown', bg: 'bg-neutral-500/20 text-neutral-300 border-neutral-500/40' };
    }
  };

  const tag = getLanguageTag(activeLanguage);

  return (
    <header className="h-14 bg-neutral-950 border-b border-neutral-800 px-4 flex items-center justify-between select-none shrink-0 z-20">
      {/* Brand & Language badges */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-600 via-indigo-500 to-teal-400 flex items-center justify-center text-white shadow-md shadow-indigo-950">
            <Cpu className="w-4 h-4" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-neutral-100 flex items-center gap-1.5 leading-none">
              <span>Code &amp; Notes Workspace</span>
            </h1>
            <div className="flex items-center gap-1.5 mt-0.5 text-[10px] text-neutral-400">
              <span className="font-mono text-neutral-300 font-semibold">SQL</span>
              <span className="text-neutral-600">•</span>
              <span className="font-mono text-neutral-300 font-semibold">C</span>
              <span className="text-neutral-600">•</span>
              <span className="font-mono text-neutral-300 font-semibold">C++</span>
              <span className="text-neutral-600">•</span>
              <span className="font-mono text-neutral-300 font-semibold">Python</span>
            </div>
          </div>
        </div>

        {/* Current Active File Tag */}
        <div className="hidden md:flex items-center gap-2 pl-3 border-l border-neutral-800">
          <span className="text-xs font-mono text-neutral-300">{activeFileName}</span>
          <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${tag.bg}`}>
            {tag.label}
          </span>
        </div>
      </div>

      {/* Middle: Layout mode switchers */}
      <div className="flex items-center bg-neutral-900 border border-neutral-800 rounded-lg p-0.5 text-xs">
        <button
          onClick={() => onChangeLayoutMode('split')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition ${
            layoutMode === 'split'
              ? 'bg-neutral-800 text-neutral-100 font-semibold shadow-sm border border-neutral-700/60'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
          title="Split View: Code and Notes together"
        >
          <Columns className="w-3.5 h-3.5 text-indigo-400" />
          <span className="hidden sm:inline">Split Workspace</span>
        </button>

        <button
          onClick={() => onChangeLayoutMode('code-only')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition ${
            layoutMode === 'code-only'
              ? 'bg-neutral-800 text-neutral-100 font-semibold shadow-sm border border-neutral-700/60'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
          title="Code Studio: Full Editor & Terminal"
        >
          <Code className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden sm:inline">Code Studio</span>
        </button>

        <button
          onClick={() => onChangeLayoutMode('notes-only')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition ${
            layoutMode === 'notes-only'
              ? 'bg-neutral-800 text-neutral-100 font-semibold shadow-sm border border-neutral-700/60'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
          title="Notes: Markdown knowledge base"
        >
          <BookOpen className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden sm:inline">Notes</span>
          <span className="px-1.5 py-0.2 bg-neutral-800 text-neutral-400 rounded-full text-[10px]">
            {notesCount}
          </span>
        </button>
      </div>

      {/* Right: Run Code action button */}
      <div className="flex items-center gap-2">
        <button
          onClick={onRunCode}
          disabled={isRunning}
          className="flex items-center gap-2 px-4 py-1.5 text-xs font-semibold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-md shadow-emerald-950 transition active:scale-95"
        >
          {isRunning ? (
            <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
          ) : (
            <Play className="w-3.5 h-3.5 fill-current" />
          )}
          <span>{isRunning ? 'Executing...' : 'Run Code'}</span>
          <kbd className="hidden lg:inline text-[10px] bg-emerald-700/50 px-1 py-0.5 rounded font-mono">
            ⌘↵
          </kbd>
        </button>
      </div>
    </header>
  );
};
