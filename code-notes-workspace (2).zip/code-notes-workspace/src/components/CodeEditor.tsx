import React, { useEffect, useRef, useState } from 'react';
import Prism from 'prismjs';
import 'prismjs/components/prism-c';
import 'prismjs/components/prism-cpp';
import 'prismjs/components/prism-python';
import 'prismjs/components/prism-sql';
import 'prismjs/components/prism-markdown';
import { 
  Play, 
  Copy, 
  Check, 
  RotateCcw, 
  FileText, 
  Maximize2, 
  Minimize2, 
  BookmarkPlus,
  Sparkles
} from 'lucide-react';
import { SupportedLanguage, WorkspaceFile } from '../types';

interface CodeEditorProps {
  file: WorkspaceFile;
  onChange: (newContent: string) => void;
  onRun: () => void;
  isRunning: boolean;
  onSendToNotes?: (snippet: string) => void;
  onResetFile?: () => void;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({
  file,
  onChange,
  onRun,
  isRunning,
  onSendToNotes,
  onResetFile,
}) => {
  const [copied, setCopied] = useState(false);
  const [fontSize, setFontSize] = useState<'text-xs' | 'text-sm' | 'text-base'>('text-sm');
  const [cursorPos, setCursorPos] = useState({ line: 1, col: 1 });
  const [isEditorExpanded, setIsEditorExpanded] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);

  // Sync scrolling between textarea and highlighted code overlay
  const handleScroll = (e: React.UIEvent<HTMLTextAreaElement>) => {
    if (preRef.current) {
      preRef.current.scrollTop = e.currentTarget.scrollTop;
      preRef.current.scrollLeft = e.currentTarget.scrollLeft;
    }
  };

  // Track cursor position
  const updateCursorPosition = () => {
    if (!textareaRef.current) return;
    const text = textareaRef.current.value.substring(0, textareaRef.current.selectionStart);
    const lines = text.split('\n');
    setCursorPos({
      line: lines.length,
      col: lines[lines.length - 1].length + 1,
    });
  };

  // Keyboard shortcuts and indentation
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // Ctrl/Cmd + Enter to Run
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      onRun();
      return;
    }

    const textarea = textareaRef.current;
    if (!textarea) return;

    // Tab key indent
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const val = textarea.value;

      if (e.shiftKey) {
        // Unindent
        const before = val.substring(0, start);
        const lineStart = before.lastIndexOf('\n') + 1;
        if (val.substring(lineStart, lineStart + 2) === '  ') {
          const newVal = val.substring(0, lineStart) + val.substring(lineStart + 2);
          onChange(newVal);
          setTimeout(() => {
            textarea.selectionStart = textarea.selectionEnd = Math.max(lineStart, start - 2);
          }, 0);
        }
      } else {
        // Indent 2 spaces
        const newVal = val.substring(0, start) + '  ' + val.substring(end);
        onChange(newVal);
        setTimeout(() => {
          textarea.selectionStart = textarea.selectionEnd = start + 2;
        }, 0);
      }
      return;
    }

    // Auto-close brackets & quotes
    const autoPairs: Record<string, string> = {
      '(': ')',
      '{': '}',
      '[': ']',
      '"': '"',
      "'": "'",
      '`': '`',
    };

    if (autoPairs[e.key]) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const val = textarea.value;
      const closeChar = autoPairs[e.key];

      // If user selected text, wrap it!
      if (start !== end) {
        e.preventDefault();
        const selected = val.substring(start, end);
        const newVal = val.substring(0, start) + e.key + selected + closeChar + val.substring(end);
        onChange(newVal);
        setTimeout(() => {
          textarea.selectionStart = start + 1;
          textarea.selectionEnd = end + 1;
        }, 0);
        return;
      }
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(file.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendSelectionToNotes = () => {
    if (!textareaRef.current || !onSendToNotes) return;
    const start = textareaRef.current.selectionStart;
    const end = textareaRef.current.selectionEnd;
    const text = textareaRef.current.value;
    const selectedText = start !== end ? text.substring(start, end) : text;
    
    const formatted = `\`\`\`${file.language}\n// From ${file.name}\n${selectedText.trim()}\n\`\`\``;
    onSendToNotes(formatted);
  };

  // Language mapping for Prism
  const getPrismLanguage = (lang: SupportedLanguage): string => {
    switch (lang) {
      case 'c': return 'c';
      case 'cpp': return 'cpp';
      case 'python': return 'python';
      case 'sql': return 'sql';
      default: return 'markdown';
    }
  };

  // Highlighted HTML
  const prismLang = getPrismLanguage(file.language);
  const highlightedCode = Prism.languages[prismLang]
    ? Prism.highlight(file.content || '', Prism.languages[prismLang], prismLang)
    : file.content;

  const lineCount = Math.max((file.content || '').split('\n').length, 1);
  const lineNumbers = Array.from({ length: lineCount }, (_, i) => i + 1);

  const getLanguageLabel = (lang: SupportedLanguage) => {
    switch (lang) {
      case 'sql': return { label: 'SQL', color: 'bg-amber-500/15 text-amber-400 border-amber-500/30' };
      case 'c': return { label: 'C (GCC 10.2)', color: 'bg-blue-500/15 text-blue-400 border-blue-500/30' };
      case 'cpp': return { label: 'C++ (G++ 10.2)', color: 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30' };
      case 'python': return { label: 'Python 3.10', color: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' };
      default: return { label: 'Markdown', color: 'bg-neutral-500/15 text-neutral-300 border-neutral-500/30' };
    }
  };

  const badge = getLanguageLabel(file.language);

  return (
    <div className={`flex flex-col h-full bg-neutral-900/90 border border-neutral-800 rounded-xl overflow-hidden shadow-2xl transition-all ${isEditorExpanded ? 'fixed inset-4 z-50' : ''}`}>
      {/* Editor Header Bar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-neutral-900 border-b border-neutral-800 select-none">
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5 font-mono text-xs font-semibold text-neutral-200">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            {file.name}
          </div>
          <span className={`px-2 py-0.5 text-xs font-medium rounded-full border ${badge.color}`}>
            {badge.label}
          </span>
        </div>

        {/* Quick Toolbar */}
        <div className="flex items-center gap-1.5">
          {/* Font size toggle */}
          <div className="hidden sm:flex items-center bg-neutral-800 rounded-lg p-0.5 border border-neutral-700/60 text-xs text-neutral-400">
            <button
              onClick={() => setFontSize('text-xs')}
              className={`px-2 py-0.5 rounded transition ${fontSize === 'text-xs' ? 'bg-neutral-700 text-neutral-100 font-semibold' : 'hover:text-neutral-200'}`}
              title="Small font"
            >
              S
            </button>
            <button
              onClick={() => setFontSize('text-sm')}
              className={`px-2 py-0.5 rounded transition ${fontSize === 'text-sm' ? 'bg-neutral-700 text-neutral-100 font-semibold' : 'hover:text-neutral-200'}`}
              title="Medium font"
            >
              M
            </button>
            <button
              onClick={() => setFontSize('text-base')}
              className={`px-2 py-0.5 rounded transition ${fontSize === 'text-base' ? 'bg-neutral-700 text-neutral-100 font-semibold' : 'hover:text-neutral-200'}`}
              title="Large font"
            >
              L
            </button>
          </div>

          {/* Send snippet to Notes */}
          {onSendToNotes && (
            <button
              onClick={handleSendSelectionToNotes}
              className="flex items-center gap-1 px-2.5 py-1 text-xs text-neutral-300 hover:text-white bg-neutral-800/80 hover:bg-neutral-700 border border-neutral-700 rounded-lg transition"
              title="Save selection or full code to Notes"
            >
              <BookmarkPlus className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden md:inline">Clip to Notes</span>
            </button>
          )}

          {/* Reset File */}
          {onResetFile && (
            <button
              onClick={onResetFile}
              className="p-1.5 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 rounded-lg transition"
              title="Reset file to sample starter"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          )}

          {/* Copy button */}
          <button
            onClick={handleCopy}
            className="p-1.5 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 rounded-lg transition"
            title="Copy Code"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>

          {/* Fullscreen toggle */}
          <button
            onClick={() => setIsEditorExpanded(!isEditorExpanded)}
            className="p-1.5 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 rounded-lg transition"
            title={isEditorExpanded ? 'Collapse' : 'Expand'}
          >
            {isEditorExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>

          {/* Run Code Button */}
          <button
            id="run-code-btn"
            onClick={onRun}
            disabled={isRunning}
            className="flex items-center gap-1.5 px-3.5 py-1 text-xs font-semibold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-sm shadow-emerald-950 transition active:scale-95 ml-1"
          >
            {isRunning ? (
              <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
            ) : (
              <Play className="w-3.5 h-3.5 fill-current" />
            )}
            <span>{isRunning ? 'Running...' : 'Run'}</span>
            <span className="hidden lg:inline text-[10px] opacity-75 font-mono">⌘↵</span>
          </button>
        </div>
      </div>

      {/* Editor Body with Line Numbers + Overlay */}
      <div className="relative flex-1 flex overflow-hidden font-mono bg-neutral-950">
        {/* Line Numbers column */}
        <div className="w-12 py-3 bg-neutral-950/80 border-r border-neutral-800/80 select-none text-right pr-3 text-neutral-600 text-xs leading-6 overflow-hidden">
          {lineNumbers.map((num) => (
            <div
              key={num}
              className={`transition-colors ${num === cursorPos.line ? 'text-neutral-300 font-semibold' : ''}`}
            >
              {num}
            </div>
          ))}
        </div>

        {/* Code Input & Display Area */}
        <div className="relative flex-1 h-full overflow-hidden">
          {/* Syntax Highlighting Background Layer */}
          <pre
            ref={preRef}
            aria-hidden="true"
            className={`absolute inset-0 p-3 m-0 overflow-hidden pointer-events-none whitespace-pre font-mono ${fontSize} leading-6 text-neutral-200 z-0`}
            dangerouslySetInnerHTML={{ __html: highlightedCode + '\n' }}
          />

          {/* Transparent Interactive Textarea Layer */}
          <textarea
            ref={textareaRef}
            value={file.content}
            onChange={(e) => {
              onChange(e.target.value);
              updateCursorPosition();
            }}
            onKeyUp={updateCursorPosition}
            onClick={updateCursorPosition}
            onScroll={handleScroll}
            onKeyDown={handleKeyDown}
            spellCheck="false"
            autoCapitalize="off"
            autoComplete="off"
            className={`absolute inset-0 w-full h-full p-3 m-0 resize-none font-mono ${fontSize} leading-6 bg-transparent text-transparent caret-white selection:bg-indigo-500/40 selection:text-white outline-none z-10`}
          />
        </div>
      </div>

      {/* Editor Status Bar */}
      <div className="flex items-center justify-between px-4 py-1 bg-neutral-900 border-t border-neutral-800/80 text-[11px] text-neutral-400 select-none font-mono">
        <div className="flex items-center gap-4">
          <span>Ln {cursorPos.line}, Col {cursorPos.col}</span>
          <span>{lineCount} lines</span>
          <span>{file.content.length} chars</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-neutral-500">UTF-8</span>
          <span className="text-neutral-500">Spaces: 2</span>
          <span className="text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            Ready
          </span>
        </div>
      </div>
    </div>
  );
};
