import React, { useState } from 'react';
import { 
  FolderCode, 
  FileCode, 
  Database, 
  Plus, 
  Trash2, 
  FilePlus, 
  Download, 
  Upload, 
  RotateCcw, 
  BookMarked, 
  ChevronDown, 
  ChevronRight, 
  Copy, 
  Sparkles,
  Layers,
  Code2
} from 'lucide-react';
import { SupportedLanguage, WorkspaceFile } from '../types';
import { SYNTAX_CHEATSHEETS } from '../data/defaultWorkspace';

interface SidebarProps {
  files: WorkspaceFile[];
  activeFileId: string;
  onSelectFile: (id: string) => void;
  onCreateFile: (name: string, language: SupportedLanguage) => void;
  onDeleteFile: (id: string) => void;
  onInsertCodeSnippet: (code: string) => void;
  onResetWorkspace: () => void;
  onExportWorkspace: () => void;
  onImportWorkspace: (file: File) => void;
  onDownloadActiveFile: () => void;
  onOpenNotesTab?: () => void;
  notesCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  files,
  activeFileId,
  onSelectFile,
  onCreateFile,
  onDeleteFile,
  onInsertCodeSnippet,
  onResetWorkspace,
  onExportWorkspace,
  onImportWorkspace,
  onDownloadActiveFile,
  onOpenNotesTab,
  notesCount,
}) => {
  const [isCreatingFile, setIsCreatingFile] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [newFileLang, setNewFileLang] = useState<SupportedLanguage>('python');
  const [showCheatSheet, setShowCheatSheet] = useState(false);
  const [cheatLang, setCheatLang] = useState<'sql' | 'c' | 'cpp' | 'python'>('sql');
  const [selectedLangFilter, setSelectedLangFilter] = useState<string>('all');

  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFileName.trim()) return;

    // Check extension
    const extMap: Record<SupportedLanguage, string> = {
      sql: '.sql',
      c: '.c',
      cpp: '.cpp',
      python: '.py',
      markdown: '.md',
    };

    let finalName = newFileName.trim();
    const expectedExt = extMap[newFileLang];
    if (!finalName.endsWith(expectedExt)) {
      finalName = `${finalName}${expectedExt}`;
    }

    onCreateFile(finalName, newFileLang);
    setNewFileName('');
    setIsCreatingFile(false);
  };

  const getLanguageBadge = (lang: SupportedLanguage) => {
    switch (lang) {
      case 'sql': return { text: 'SQL', color: 'text-amber-400 bg-amber-500/15' };
      case 'c': return { text: 'C', color: 'text-blue-400 bg-blue-500/15' };
      case 'cpp': return { text: 'C++', color: 'text-indigo-400 bg-indigo-500/15' };
      case 'python': return { text: 'PY', color: 'text-emerald-400 bg-emerald-500/15' };
      default: return { text: 'MD', color: 'text-neutral-400 bg-neutral-500/15' };
    }
  };

  const filteredFiles = files.filter(
    (f) => selectedLangFilter === 'all' || f.language === selectedLangFilter
  );

  return (
    <aside className="w-64 h-full bg-neutral-950 border-r border-neutral-800 flex flex-col select-none text-xs">
      {/* Workspace Header */}
      <div className="p-3 border-b border-neutral-800 flex items-center justify-between">
        <div className="flex items-center gap-2 font-semibold text-neutral-200">
          <FolderCode className="w-4 h-4 text-indigo-400" />
          <span>Files &amp; Scripts</span>
        </div>
        <button
          onClick={() => setIsCreatingFile(true)}
          className="p-1 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-lg transition"
          title="Create New File"
        >
          <FilePlus className="w-4 h-4" />
        </button>
      </div>

      {/* Language Quick Filter */}
      <div className="flex items-center gap-1 px-3 py-2 border-b border-neutral-850 overflow-x-auto">
        {['all', 'sql', 'c', 'cpp', 'python'].map((lang) => (
          <button
            key={lang}
            onClick={() => setSelectedLangFilter(lang)}
            className={`px-2 py-0.5 rounded text-[10px] font-medium uppercase transition shrink-0 ${
              selectedLangFilter === lang
                ? 'bg-neutral-800 text-neutral-100 font-bold'
                : 'text-neutral-500 hover:text-neutral-300'
            }`}
          >
            {lang}
          </button>
        ))}
      </div>

      {/* File Tree List */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {filteredFiles.map((file) => {
          const isSelected = file.id === activeFileId;
          const badge = getLanguageBadge(file.language);

          return (
            <div
              key={file.id}
              className={`group flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer transition border ${
                isSelected
                  ? 'bg-neutral-800/90 border-neutral-700 text-neutral-100 font-medium'
                  : 'bg-transparent border-transparent hover:bg-neutral-900 text-neutral-400 hover:text-neutral-200'
              }`}
              onClick={() => onSelectFile(file.id)}
            >
              <div className="flex items-center gap-2 truncate">
                <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold ${badge.color}`}>
                  {badge.text}
                </span>
                <span className="truncate font-mono text-xs">{file.name}</span>
              </div>

              {/* Actions on hover */}
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
                {files.length > 1 && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteFile(file.id);
                    }}
                    className="p-1 hover:text-rose-400 text-neutral-500 rounded transition"
                    title="Delete file"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>
          );
        })}

        {/* Modal: New File Inline Form */}
        {isCreatingFile && (
          <form
            onSubmit={handleCreateSubmit}
            className="p-2.5 bg-neutral-900 border border-indigo-500/50 rounded-lg my-2 space-y-2"
          >
            <div className="text-[11px] font-semibold text-neutral-200">New Workspace File</div>
            <select
              value={newFileLang}
              onChange={(e) => setNewFileLang(e.target.value as SupportedLanguage)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded p-1 text-neutral-300 text-xs"
            >
              <option value="sql">SQL Query (.sql)</option>
              <option value="c">C Source (.c)</option>
              <option value="cpp">C++ Source (.cpp)</option>
              <option value="python">Python Script (.py)</option>
            </select>
            <input
              type="text"
              value={newFileName}
              onChange={(e) => setNewFileName(e.target.value)}
              placeholder="e.g. analysis or test"
              autoFocus
              className="w-full bg-neutral-950 border border-neutral-800 rounded p-1 text-neutral-200 font-mono text-xs focus:outline-none focus:border-indigo-500"
            />
            <div className="flex items-center justify-end gap-1.5 pt-1">
              <button
                type="button"
                onClick={() => setIsCreatingFile(false)}
                className="px-2 py-1 text-[11px] text-neutral-400 hover:text-neutral-200"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-2.5 py-1 text-[11px] bg-indigo-600 hover:bg-indigo-500 text-white rounded font-medium"
              >
                Create
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Cheat Sheet & Quick Reference Drawer Button */}
      <div className="p-2 border-t border-neutral-850">
        <button
          onClick={() => setShowCheatSheet(!showCheatSheet)}
          className="w-full flex items-center justify-between p-2 rounded-lg bg-neutral-900/60 hover:bg-neutral-800 border border-neutral-800/80 text-neutral-300 transition"
        >
          <div className="flex items-center gap-2">
            <BookMarked className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-medium text-xs">Syntax Cheat Sheets</span>
          </div>
          {showCheatSheet ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
        </button>

        {/* Cheat Sheets Panel */}
        {showCheatSheet && (
          <div className="mt-2 p-2 bg-neutral-900 border border-neutral-800 rounded-lg space-y-2 max-h-56 overflow-y-auto font-mono text-[11px]">
            {/* Lang switcher */}
            <div className="flex items-center justify-between border-b border-neutral-800 pb-1">
              {(['sql', 'c', 'cpp', 'python'] as const).map((lang) => (
                <button
                  key={lang}
                  onClick={() => setCheatLang(lang)}
                  className={`px-1.5 py-0.5 rounded text-[10px] uppercase font-bold ${
                    cheatLang === lang ? 'text-amber-400 bg-neutral-800' : 'text-neutral-500'
                  }`}
                >
                  {lang}
                </button>
              ))}
            </div>

            {/* Snippets */}
            <div className="space-y-1.5">
              {SYNTAX_CHEATSHEETS[cheatLang].snippets.map((snip, i) => (
                <div
                  key={i}
                  className="p-1.5 bg-neutral-950 rounded border border-neutral-800/60 hover:border-neutral-700 group"
                >
                  <div className="flex items-center justify-between text-[10px] text-neutral-400 font-sans mb-1">
                    <span>{snip.label}</span>
                    <button
                      onClick={() => onInsertCodeSnippet(snip.code)}
                      className="opacity-0 group-hover:opacity-100 text-indigo-400 hover:text-indigo-300 flex items-center gap-0.5 transition"
                      title="Insert into active code editor"
                    >
                      <Plus className="w-2.5 h-2.5" />
                      <span>Insert</span>
                    </button>
                  </div>
                  <pre className="text-neutral-300 overflow-x-auto text-[10px] whitespace-pre-wrap">
                    {snip.code}
                  </pre>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Bottom Footer Actions */}
      <div className="p-2 border-t border-neutral-800 space-y-1 bg-neutral-950/80">
        <button
          onClick={onDownloadActiveFile}
          className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900 transition text-[11px]"
        >
          <Download className="w-3.5 h-3.5 text-neutral-500" />
          <span>Download Current File</span>
        </button>

        <div className="flex items-center justify-between gap-1">
          <button
            onClick={onExportWorkspace}
            className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900 transition text-[11px]"
            title="Export full workspace to JSON"
          >
            <Download className="w-3 h-3" />
            <span>Export JSON</span>
          </button>

          <label className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900 transition text-[11px] cursor-pointer">
            <Upload className="w-3 h-3" />
            <span>Import</span>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  onImportWorkspace(file);
                }
              }}
            />
          </label>
        </div>

        <button
          onClick={onResetWorkspace}
          className="w-full flex items-center justify-center gap-1.5 py-1 rounded text-neutral-500 hover:text-rose-400 hover:bg-neutral-900/60 transition text-[10px]"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Reset Sample Files</span>
        </button>
      </div>
    </aside>
  );
};
