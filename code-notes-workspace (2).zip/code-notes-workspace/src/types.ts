export type SupportedLanguage = 'sql' | 'c' | 'cpp' | 'python' | 'markdown';

export interface WorkspaceFile {
  id: string;
  name: string;
  language: SupportedLanguage;
  content: string;
  isDefault?: boolean;
  linkedNoteId?: string;
  createdAt: number;
  updatedAt: number;
}

export interface WorkspaceNote {
  id: string;
  title: string;
  content: string;
  tags: string[];
  languageTopic: 'all' | 'sql' | 'c' | 'cpp' | 'python' | 'general';
  linkedFileId?: string;
  isDefault?: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface SqlColumn {
  name: string;
  type: string;
}

export interface SqlTableInfo {
  name: string;
  columns: SqlColumn[];
  rowCount: number;
}

export interface SqlQueryResult {
  columns: string[];
  values: (string | number | null | boolean)[][];
  rowsAffected?: number;
  executionTimeMs: number;
  message?: string;
}

export interface ExecutionResult {
  status: 'idle' | 'running' | 'success' | 'error';
  language: SupportedLanguage;
  stdout: string;
  stderr: string;
  exitCode?: number;
  executionTimeMs?: number;
  sqlResult?: SqlQueryResult;
  sqlTables?: SqlTableInfo[];
  timestamp?: number;
}

export type LayoutMode = 'split' | 'code-only' | 'notes-only';
