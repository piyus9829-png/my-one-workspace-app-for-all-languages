import { WorkspaceFile, WorkspaceNote } from '../types';

export const INITIAL_SQL_SEED = `
-- Setup sample database schema
CREATE TABLE IF NOT EXISTS departments (
  department_id INTEGER PRIMARY KEY,
  dept_name TEXT NOT NULL,
  location TEXT NOT NULL,
  budget INTEGER
);

CREATE TABLE IF NOT EXISTS employees (
  employee_id INTEGER PRIMARY KEY,
  full_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  role TEXT NOT NULL,
  salary INTEGER NOT NULL,
  department_id INTEGER,
  hire_date DATE,
  FOREIGN KEY (department_id) REFERENCES departments(department_id)
);

CREATE TABLE IF NOT EXISTS projects (
  project_id INTEGER PRIMARY KEY,
  project_name TEXT NOT NULL,
  lead_id INTEGER,
  status TEXT DEFAULT 'Planning',
  FOREIGN KEY (lead_id) REFERENCES employees(employee_id)
);

-- Populate departments
INSERT OR IGNORE INTO departments (department_id, dept_name, location, budget) VALUES
  (101, 'Engineering', 'San Francisco', 850000),
  (102, 'Data Science', 'New York', 620000),
  (103, 'Product Design', 'Austin', 410000),
  (104, 'Cloud Infrastructure', 'Seattle', 920000);

-- Populate employees
INSERT OR IGNORE INTO employees (employee_id, full_name, email, role, salary, department_id, hire_date) VALUES
  (1, 'Alex Rivera', 'alex.r@techcorp.io', 'Principal Architect', 185000, 101, '2021-03-15'),
  (2, 'Sophia Chen', 'sophia.c@techcorp.io', 'Senior ML Engineer', 165000, 102, '2022-01-10'),
  (3, 'Marcus Vance', 'marcus.v@techcorp.io', 'Staff DevOps Engineer', 170000, 104, '2020-11-01'),
  (4, 'Elena Rostova', 'elena.r@techcorp.io', 'UX Lead', 145000, 103, '2022-06-20'),
  (5, 'Liam Patel', 'liam.p@techcorp.io', 'Fullstack Engineer', 135000, 101, '2023-04-12'),
  (6, 'Hannah Kim', 'hannah.k@techcorp.io', 'Data Analyst', 120000, 102, '2023-08-01');

-- Populate projects
INSERT OR IGNORE INTO projects (project_id, project_name, lead_id, status) VALUES
  (501, 'NextGen Cloud Engine', 1, 'In Progress'),
  (502, 'Deep Learning Pipeline', 2, 'In Progress'),
  (503, 'Design System 3.0', 4, 'Completed'),
  (504, 'Zero Trust Security', 3, 'In Progress');
`;

export const DEFAULT_FILES: WorkspaceFile[] = [
  {
    id: 'file-sql-1',
    name: 'queries.sql',
    language: 'sql',
    linkedNoteId: 'note-sql-1',
    content: `-- SQL Query Lab: Exploring Company Database
-- Tables available: departments, employees, projects

-- 1. Get average salary and employee count per department with total budget
SELECT 
  d.dept_name AS Department,
  d.location AS City,
  COUNT(e.employee_id) AS Headcount,
  ROUND(AVG(e.salary), 2) AS Avg_Salary,
  MAX(e.salary) AS Max_Salary,
  d.budget AS Dept_Budget
FROM departments d
LEFT JOIN employees e ON d.department_id = e.department_id
GROUP BY d.department_id
ORDER BY Avg_Salary DESC;

-- 2. Projects and their team leads
SELECT 
  p.project_name AS Project,
  p.status AS Status,
  e.full_name AS Project_Lead,
  e.role AS Lead_Role,
  d.dept_name AS Department
FROM projects p
JOIN employees e ON p.lead_id = e.employee_id
JOIN departments d ON e.department_id = d.department_id;
`,
    createdAt: Date.now() - 3600000 * 4,
    updatedAt: Date.now() - 3600000 * 4,
  },
  {
    id: 'file-c-1',
    name: 'pointers_and_memory.c',
    language: 'c',
    linkedNoteId: 'note-c-1',
    content: `/*
 * C Programming Workspace: Pointers & Dynamic Memory
 * Demonstrates pointer arithmetic, structs, and dynamic allocation.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int id;
    char name[32];
    double score;
} Student;

void printStudent(const Student *s) {
    printf("[ID: %d] %-12s | Score: %.1f\\n", s->id, s->name, s->score);
}

void updateScore(Student *s, double bonus) {
    s->score += bonus;
}

int main() {
    printf("=== C Memory & Structs Demo ===\\n\\n");

    int count = 3;
    Student *roster = (Student *)malloc(count * sizeof(Student));

    if (roster == NULL) {
        fprintf(stderr, "Memory allocation failed!\\n");
        return 1;
    }

    // Initialize roster
    roster[0].id = 101; strcpy(roster[0].name, "Alice");   roster[0].score = 88.5;
    roster[1].id = 102; strcpy(roster[1].name, "Bob");     roster[1].score = 92.0;
    roster[2].id = 103; strcpy(roster[2].name, "Charlie"); roster[2].score = 79.5;

    printf("Original Student Records:\\n");
    for (int i = 0; i < count; i++) {
        printStudent(&roster[i]);
    }

    printf("\\nApplying 5.0 bonus to all students...\\n");
    for (int i = 0; i < count; i++) {
        updateScore(&roster[i], 5.0);
        printStudent(&roster[i]);
    }

    // Clean up memory
    free(roster);
    printf("\\nDynamic memory successfully freed.\\n");

    return 0;
}
`,
    createdAt: Date.now() - 3600000 * 3,
    updatedAt: Date.now() - 3600000 * 3,
  },
  {
    id: 'file-cpp-1',
    name: 'stl_and_algorithms.cpp',
    language: 'cpp',
    linkedNoteId: 'note-cpp-1',
    content: `/*
 * C++ Modern Programming: STL Vectors, Maps & Lambdas
 */

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <map>
#include <iomanip>

class Developer {
public:
    std::string name;
    std::string primaryLang;
    int yearsExp;

    Developer(std::string n, std::string lang, int exp)
        : name(n), primaryLang(lang), yearsExp(exp) {}

    void display() const {
        std::cout << "  " << std::left << std::setw(12) << name 
                  << " | Language: " << std::setw(8) << primaryLang 
                  << " | Experience: " << yearsExp << " yrs\\n";
    }
};

int main() {
    std::cout << "=== C++ STL & Modern Features Demo ===\\n\\n";

    std::vector<Developer> team = {
        Developer("Elena", "C++", 8),
        Developer("Taro", "Python", 4),
        Developer("Mateo", "SQL", 6),
        Developer("Ananya", "C", 10),
        Developer("Jordan", "Python", 2)
    };

    // Sort team by years of experience descending using a modern lambda
    std::sort(team.begin(), team.end(), [](const Developer& a, const Developer& b) {
        return a.yearsExp > b.yearsExp;
    });

    std::cout << "Engineering Team Sorted by Seniority:\\n";
    for (const auto& dev : team) {
        dev.display();
    }

    // Count developers per language using std::map
    std::map<std::string, int> langCounts;
    for (const auto& dev : team) {
        langCounts[dev.primaryLang]++;
    }

    std::cout << "\\nLanguage Distribution in Team:\\n";
    for (const auto& pair : langCounts) {
        std::cout << "  * " << pair.first << ": " << pair.second << " developer(s)\\n";
    }

    return 0;
}
`,
    createdAt: Date.now() - 3600000 * 2,
    updatedAt: Date.now() - 3600000 * 2,
  },
  {
    id: 'file-py-1',
    name: 'data_pipeline.py',
    language: 'python',
    linkedNoteId: 'note-py-1',
    content: `"""
Python Data Processing & Analytics Workspace
Demonstrates list comprehensions, statistics, and text manipulation.
"""

from collections import Counter
import math

# Sample dataset: Server request latencies (ms)
latencies = [45, 62, 53, 120, 48, 77, 95, 305, 52, 60, 88, 41, 195, 56, 68]

def analyze_latencies(data):
    sorted_data = sorted(data)
    n = len(sorted_data)
    
    mean = sum(sorted_data) / n
    median = sorted_data[n // 2] if n % 2 != 0 else (sorted_data[n // 2 - 1] + sorted_data[n // 2]) / 2
    
    # 95th percentile
    p95_idx = math.ceil(0.95 * n) - 1
    p95 = sorted_data[p95_idx]
    
    # Outliers (> 150ms)
    outliers = [x for x in sorted_data if x > 150]
    
    return {
        "count": n,
        "mean": round(mean, 2),
        "median": median,
        "p95": p95,
        "min": min(sorted_data),
        "max": max(sorted_data),
        "outliers": outliers
    }

metrics = analyze_latencies(latencies)

print("=== Server Latency Analysis ===")
print(f"Sample Count : {metrics['count']} requests")
print(f"Min / Max    : {metrics['min']}ms / {metrics['max']}ms")
print(f"Mean Latency : {metrics['mean']}ms")
print(f"Median (p50) : {metrics['median']}ms")
print(f"95th %ile    : {metrics['p95']}ms")
print(f"Outliers     : {metrics['outliers']} (latencies > 150ms)")
print("\\nLatency Distribution Histogram:")

# Quick text visualizer
for val in sorted(latencies):
    bars = "#" * (val // 15)
    print(f"{val:>3}ms | {bars}")
`,
    createdAt: Date.now() - 3600000 * 1,
    updatedAt: Date.now() - 3600000 * 1,
  },
];

export const DEFAULT_NOTES: WorkspaceNote[] = [
  {
    id: 'note-sql-1',
    title: 'SQL Reference & Query Techniques',
    languageTopic: 'sql',
    linkedFileId: 'file-sql-1',
    tags: ['joins', 'aggregation', 'schema'],
    content: `# SQL Core Techniques & Notes

## Execution Order
SQL statements are processed in this logical sequence:
1. \`FROM\` / \`JOIN\`
2. \`WHERE\` (row filtering)
3. \`GROUP BY\` (grouping rows)
4. \`HAVING\` (group filtering)
5. \`SELECT\` (projection & aliases)
6. \`DISTINCT\`
7. \`ORDER BY\`
8. \`LIMIT\` / \`OFFSET\`

## Common Joins
- **INNER JOIN**: Only records with matches in both tables.
- **LEFT JOIN**: All records from left table, NULL if no match on right.
- **CROSS JOIN**: Cartesian product (all combinations).

## Useful Snippets
\`\`\`sql
-- Group aggregation with conditional counting
SELECT department_id, 
       COUNT(*) as total_staff,
       AVG(salary) as average_pay
FROM employees
WHERE salary > 50000
GROUP BY department_id
HAVING COUNT(*) >= 2;
\`\`\`

## Indexing Tip
Always create indexes on columns used frequently in \`WHERE\`, \`JOIN ON\`, or \`ORDER BY\` to avoid full table scans.
`,
    createdAt: Date.now() - 3600000 * 4,
    updatedAt: Date.now() - 3600000 * 4,
  },
  {
    id: 'note-c-1',
    title: 'C Memory, Pointers & Safety',
    languageTopic: 'c',
    linkedFileId: 'file-c-1',
    tags: ['pointers', 'memory', 'malloc'],
    content: `# C Memory Architecture & Best Practices

## Memory Segments
- **Stack**: Fast, automatic storage for local variables and function call frames.
- **Heap**: Dynamic allocation via \`malloc\`, \`calloc\`, \`realloc\`. Must be explicitly \`free\`d.
- **Data / BSS**: Global and static variables.
- **Text (Code)**: Read-only machine instructions.

## The Golden Rules of Pointers
1. **Always check for NULL** after \`malloc\`:
   \`\`\`c
   int *ptr = (int *)malloc(10 * sizeof(int));
   if (ptr == NULL) {
       // Handle out-of-memory gracefully
   }
   \`\`\`
2. **Every \`malloc\` must have a matching \`free\`**:
   Avoid memory leaks by releasing memory before the pointer goes out of scope.
3. **Nullify dangling pointers**:
   \`\`\`c
   free(ptr);
   ptr = NULL; // Prevents accidental double-free or wild dereferences
   \`\`\`

## Pass by Reference in C
Pass a pointer to modify the caller's variable:
\`\`\`c
void increment(int *val) {
    (*val)++;
}
\`\`\`
`,
    createdAt: Date.now() - 3600000 * 3,
    updatedAt: Date.now() - 3600000 * 3,
  },
  {
    id: 'note-cpp-1',
    title: 'C++ STL Containers & Modern Idioms',
    languageTopic: 'cpp',
    linkedFileId: 'file-cpp-1',
    tags: ['stl', 'oop', 'templates', 'vector'],
    content: `# Modern C++ & STL Cheat Sheet

## Container Choices
- \`std::vector<T>\`: Contiguous array, $O(1)$ random access, cache-friendly. Default choice for 90% of cases.
- \`std::map<K, V>\`: Red-black balanced binary search tree, sorted keys, $O(\\log n)$ lookup.
- \`std::unordered_map<K, V>\`: Hash table, $O(1)$ average lookup, unsorted.
- \`std::deque<T>\`: Double-ended queue with $O(1)$ push/pop at both ends.

## RAII (Resource Acquisition Is Initialization)
Use smart pointers instead of raw pointers:
\`\`\`cpp
#include <memory>

// Unique ownership (cannot be copied, can be moved)
auto ptr = std::make_unique<MyClass>(arg1, arg2);

// Shared reference counted ownership
auto shared = std::make_shared<MyClass>();
\`\`\`

## Modern Lambdas
\`\`\`cpp
auto isEven = [](int n) { return n % 2 == 0; };
\`\`\`
`,
    createdAt: Date.now() - 3600000 * 2,
    updatedAt: Date.now() - 3600000 * 2,
  },
  {
    id: 'note-py-1',
    title: 'Python Idioms & Performance',
    languageTopic: 'python',
    linkedFileId: 'file-py-1',
    tags: ['pythonic', 'generators', 'dict'],
    content: `# Pythonic Best Practices & Notes

## List & Dict Comprehensions
\`\`\`python
# Squared numbers for even inputs
evens_squared = [x**2 for x in range(20) if x % 2 == 0]

# Inverting a dictionary
original = {'a': 1, 'b': 2, 'c': 3}
inverted = {v: k for k, v in original.items()}
\`\`\`

## Generator Expressions (Memory Efficient)
When processing huge streams, avoid holding everything in memory:
\`\`\`python
total_sum = sum(x**2 for x in range(1_000_000))
\`\`\`

## Helpful Built-in Libraries
- \`collections\`: \`defaultdict\`, \`Counter\`, \`deque\`
- \`itertools\`: \`chain\`, \`combinations\`, \`groupby\`
- \`functools\`: \`lru_cache\`, \`reduce\`
- \`dataclasses\`: Fast boilerplate-free class definitions
`,
    createdAt: Date.now() - 3600000 * 1,
    updatedAt: Date.now() - 3600000 * 1,
  },
  {
    id: 'note-general-1',
    title: 'Multi-Language Concept Map',
    languageTopic: 'general',
    tags: ['comparisons', 'concepts', 'syntax'],
    content: `# Comparative Reference: SQL, C, C++, Python

| Feature / Concept | SQL | C | C++ | Python |
| :--- | :--- | :--- | :--- | :--- |
| **Typing** | Strict Static | Static (weak) | Strict Static | Dynamic Strong |
| **Memory** | Database Engine | Manual (\`malloc\`/\`free\`) | RAII / Smart Ptrs | Automatic GC |
| **Paradigm** | Declarative / Relational | Procedural | Multi-paradigm / OOP | Multi-paradigm |
| **Primary Use** | Data retrieval & storage | Systems, OS, Embedded | High-performance, Games, Engines | Scripting, AI, Web, Data |

## Notes for Today:
- [ ] Practice joins between \`departments\` and \`projects\` in SQL
- [ ] Implement a binary search tree in C++ using classes
- [ ] Benchmark memory footprint in C vs Python
`,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  }
];

export const SYNTAX_CHEATSHEETS = {
  sql: {
    title: 'SQL Quick Syntax Reference',
    snippets: [
      { label: 'SELECT with Filter', code: 'SELECT column1, column2 FROM table_name WHERE condition ORDER BY column1 DESC;' },
      { label: 'INNER JOIN', code: 'SELECT a.name, b.title FROM table_a a JOIN table_b b ON a.id = b.a_id;' },
      { label: 'GROUP BY & Aggregate', code: 'SELECT category, COUNT(*), AVG(price) FROM products GROUP BY category HAVING COUNT(*) > 5;' },
      { label: 'CREATE TABLE', code: 'CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);' },
      { label: 'INSERT Statement', code: 'INSERT INTO users (username) VALUES (\'coder42\'), (\'dev_guru\');' },
      { label: 'UPDATE Statement', code: 'UPDATE users SET username = \'new_name\' WHERE id = 1;' },
    ]
  },
  c: {
    title: 'C Quick Syntax Reference',
    snippets: [
      { label: 'Standard Main Boilerplate', code: '#include <stdio.h>\n\nint main(void) {\n    printf("Hello from C!\\n");\n    return 0;\n}' },
      { label: 'Dynamic Memory Allocation', code: 'int *arr = (int *)malloc(size * sizeof(int));\nif (arr != NULL) {\n    // use array\n    free(arr);\n}' },
      { label: 'Struct Definition', code: 'typedef struct {\n    int id;\n    char name[50];\n} Person;\n\nPerson p = {1, "Alex"};' },
      { label: 'Pointer Dereferencing', code: 'int x = 42;\nint *p = &x;\n*p = 100; // changes x to 100' },
      { label: 'String Copy / Compare', code: '#include <string.h>\nchar dest[20];\nstrcpy(dest, "source");\nif (strcmp(dest, "source") == 0) { /* matches */ }' },
    ]
  },
  cpp: {
    title: 'C++ Quick Syntax Reference',
    snippets: [
      { label: 'Class Definition', code: 'class BankAccount {\nprivate:\n    double balance;\npublic:\n    BankAccount(double b) : balance(b) {}\n    double getBalance() const { return balance; }\n};' },
      { label: 'Vector Usage', code: '#include <vector>\nstd::vector<int> nums = {10, 20, 30};\nnums.push_back(40);\nfor (const auto& n : nums) {\n    std::cout << n << " ";\n}' },
      { label: 'Map Lookup', code: '#include <map>\nstd::map<std::string, int> scores;\nscores["Alice"] = 95;\nfor (auto const& [name, score] : scores) {\n    std::cout << name << ": " << score << "\\n";\n}' },
      { label: 'Lambda Expression', code: 'auto add = [](int a, int b) -> int { return a + b; };\nstd::cout << add(3, 4);' },
      { label: 'Smart Pointers', code: '#include <memory>\nauto ptr = std::make_unique<int>(42);' },
    ]
  },
  python: {
    title: 'Python Quick Syntax Reference',
    snippets: [
      { label: 'List Comprehension', code: 'squared = [x**2 for x in range(10) if x % 2 == 0]' },
      { label: 'Dictionary Iteration', code: 'user_scores = {"Alice": 92, "Bob": 85}\nfor user, score in user_scores.items():\n    print(f"{user}: {score}")' },
      { label: 'Function with Type Hints', code: 'def calculate_discount(price: float, discount: float = 0.1) -> float:\n    """Return final discounted price."""\n    return price * (1.0 - discount)' },
      { label: 'File Context Manager', code: 'with open("output.txt", "w") as f:\n    f.write("Workspace log output\\n")' },
      { label: 'Class Definition', code: 'class Point:\n    def __init__(self, x: float, y: float):\n        self.x = x\n        self.y = y\n    def __repr__(self):\n        return f"Point({self.x}, {self.y})"' },
    ]
  }
};
